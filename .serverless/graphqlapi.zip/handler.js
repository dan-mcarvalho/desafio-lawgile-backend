const handler = require('serverless-express/handler');

exports.handler = handler(server);